import { Button } from "@/components/ui/button";
import { Check, Star, MapPin, Clock, DollarSign, ArrowRight } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col bg-background font-sans">
      {/* HEADER */}
      <header className="bg-white/90 backdrop-blur-md sticky top-0 z-50 border-b border-hybrid-sand/30 shadow-sm">
        <div className="container mx-auto py-4 flex flex-col md:flex-row justify-between items-center">
          <div className="text-center md:text-left mb-4 md:mb-0">
            <img 
              src="/images/logo.png" 
              alt="K.O. Real Estate Team - Spirit Real Estate Group" 
              className="h-16 md:h-20 w-auto object-contain"
            />
          </div>
          
          <nav className="hidden md:flex space-x-8">
            {["Home", "Services", "Neighborhoods", "About", "Contact"].map((item) => (
              <a 
                key={item} 
                href={`#${item.toLowerCase()}`}
                className="font-ui font-medium text-sm text-hybrid-charcoal hover:text-hybrid-gold transition-colors relative group"
              >
                {item}
                <span className="absolute -bottom-1 left-1/2 w-0 h-0.5 bg-hybrid-gold transition-all duration-300 group-hover:w-full group-hover:left-0"></span>
              </a>
            ))}
          </nav>
          
          <Button className="md:hidden bg-hybrid-blue text-white">Menu</Button>
        </div>
      </header>

      <main className="flex-grow">
        {/* HERO SECTION */}
        <section className="relative py-20 md:py-32 overflow-hidden">
          <div className="absolute inset-0 z-0">
            {/* Abstract background pattern or image placeholder */}
            <div className="absolute inset-0 bg-gradient-to-br from-hybrid-pearl via-white to-hybrid-sand/20 opacity-80"></div>
            <div className="absolute top-0 right-0 w-1/2 h-full bg-hybrid-blue/5 skew-x-12 transform origin-top-right"></div>
          </div>
          
          <div className="container relative z-10 grid md:grid-cols-2 gap-12 items-center">
            <div className="text-center md:text-left space-y-6">
              <div className="inline-block px-3 py-1 border border-hybrid-gold/30 rounded-full bg-hybrid-gold/5 backdrop-blur-sm">
                <span className="font-ui text-xs font-bold text-hybrid-gold tracking-widest uppercase">
                  Houston & DFW Luxury Rentals
                </span>
              </div>
              
              <h1 className="font-serif font-black text-5xl md:text-6xl lg:text-7xl text-hybrid-ink leading-[1.1]">
                Find Your Next <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-hybrid-blue to-hybrid-gold">
                  Luxury Home
                </span>
              </h1>
              
              <p className="text-lg md:text-xl text-hybrid-charcoal/80 max-w-lg mx-auto md:mx-0 font-light leading-relaxed">
                Experience the pinnacle of apartment locating. We specialize in finding your perfect luxury rental in Houston and DFW—fast, easy, and 100% free.
              </p>
              
              <div className="pt-4 flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
                <button 
                  onClick={() => window.open('https://form.typeform.com/to/S0I5M7ZZ?typeform-source=ko-real-estate.typeform.com', '_blank')}
                  className="btn-luxury group flex items-center justify-center gap-2"
                >
                  Start Free Search
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
                <p className="text-xs text-hybrid-charcoal/60 mt-2 sm:mt-0 sm:self-center font-ui">
                  <Check className="w-3 h-3 inline mr-1 text-hybrid-gold" />
                  Takes &lt; 2 mins
                </p>
              </div>
            </div>
            
            <div className="relative hidden md:block">
              {/* Image Placeholder - In production use real luxury apartment image */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white transform rotate-2 hover:rotate-0 transition-transform duration-700">
                <div className="aspect-[4/5] bg-gray-200 relative">
                   <div className="absolute inset-0 flex items-center justify-center text-hybrid-charcoal/30 font-serif italic">
                     Luxury Interior Image
                   </div>
                   {/* Overlay gradient */}
                   <div className="absolute inset-0 bg-gradient-to-t from-hybrid-ink/40 to-transparent"></div>
                   
                   <div className="absolute bottom-6 left-6 right-6 text-white">
                     <div className="flex items-center gap-2 mb-2">
                       <Star className="w-4 h-4 text-hybrid-gold fill-hybrid-gold" />
                       <Star className="w-4 h-4 text-hybrid-gold fill-hybrid-gold" />
                       <Star className="w-4 h-4 text-hybrid-gold fill-hybrid-gold" />
                       <Star className="w-4 h-4 text-hybrid-gold fill-hybrid-gold" />
                       <Star className="w-4 h-4 text-hybrid-gold fill-hybrid-gold" />
                     </div>
                     <p className="font-serif text-xl">"The best moving experience I've ever had."</p>
                     <p className="font-ui text-xs mt-2 opacity-80">- Sarah J., Downtown Houston</p>
                   </div>
                </div>
              </div>
              
              {/* Decorative Element */}
              <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-hybrid-gold/10 rounded-full blur-3xl"></div>
            </div>
          </div>
        </section>

        {/* FEATURES SECTION */}
        <section className="py-20 bg-white">
          <div className="container">
            <div className="text-center max-w-3xl mx-auto mb-16">
              <h2 className="font-serif font-bold text-4xl text-hybrid-ink mb-4">
                Why Renters Choose K.O.
              </h2>
              <div className="gold-thread"></div>
              <p className="text-hybrid-charcoal/80 text-lg">
                We elevate the standard of apartment locating with a service designed around your needs, not just listings.
              </p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {[
                {
                  icon: <DollarSign className="w-8 h-8 text-hybrid-gold" />,
                  title: "100% Free Service",
                  desc: "Our service is completely free for you. We are compensated by the properties from their marketing budget, never affecting your rent."
                },
                {
                  icon: <MapPin className="w-8 h-8 text-hybrid-gold" />,
                  title: "Local Expertise",
                  desc: "From Midtown Houston to Uptown Dallas, we know every building, special, and hidden gem in the luxury market."
                },
                {
                  icon: <Clock className="w-8 h-8 text-hybrid-gold" />,
                  title: "Fast Turnaround",
                  desc: "Need to move soon? We provide curated lists with real-time availability and pricing within 24 hours."
                }
              ].map((feature, idx) => (
                <div key={idx} className="p-8 rounded-xl bg-hybrid-pearl border border-hybrid-sand/30 hover:shadow-lg hover:-translate-y-2 transition-all duration-300 group">
                  <div className="mb-6 p-4 bg-white rounded-full inline-block shadow-sm group-hover:scale-110 transition-transform duration-300">
                    {feature.icon}
                  </div>
                  <h3 className="font-serif font-bold text-xl text-hybrid-ink mb-3">{feature.title}</h3>
                  <p className="text-hybrid-charcoal/70 leading-relaxed">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section className="py-20 bg-hybrid-pearl">
          <div className="container">
            <div className="grid md:grid-cols-2 gap-16 items-center">
              <div className="order-2 md:order-1">
                <h2 className="font-serif font-bold text-4xl text-hybrid-ink mb-6">
                  Your Journey to the <br/> Perfect Home
                </h2>
                <div className="space-y-8">
                  {[
                    { step: "01", title: "Share Your Wishlist", desc: "Tell us your budget, preferred neighborhoods, and must-haves." },
                    { step: "02", title: "Get Curated Options", desc: "Receive a personalized list of verified luxury apartments with current specials." },
                    { step: "03", title: "Tour & Apply", desc: "We schedule your tours and guide you through the application process." },
                    { step: "04", title: "Move In & Relax", desc: "Enjoy your new home with confidence, knowing you got the best deal." }
                  ].map((item) => (
                    <div key={item.step} className="flex gap-6">
                      <div className="font-serif font-black text-4xl text-hybrid-gold/20 leading-none">
                        {item.step}
                      </div>
                      <div>
                        <h4 className="font-ui font-bold text-lg text-hybrid-ink mb-2">{item.title}</h4>
                        <p className="text-hybrid-charcoal/70">{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-10">
                  <button 
                    onClick={() => window.open('https://form.typeform.com/to/S0I5M7ZZ?typeform-source=ko-real-estate.typeform.com', '_blank')}
                    className="font-ui font-bold text-hybrid-blue hover:text-hybrid-gold transition-colors flex items-center gap-2"
                  >
                    Start Your Search Now <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
              <div className="order-1 md:order-2 relative">
                 <div className="aspect-square bg-white rounded-full p-8 shadow-xl relative z-10 flex items-center justify-center text-center">
                    <div>
                      <p className="font-serif text-6xl font-black text-hybrid-blue mb-2">$100</p>
                      <p className="font-ui font-bold text-xl text-hybrid-ink uppercase tracking-widest">Rebate</p>
                      <p className="text-sm text-hybrid-charcoal/60 mt-2 max-w-[200px] mx-auto">Must ask at time of application. Terms apply.</p>
                    </div>
                 </div>
                 <div className="absolute inset-0 border border-dashed border-hybrid-gold rounded-full animate-spin-slow" style={{animationDuration: '20s'}}></div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA SECTION */}
        <section className="py-24 bg-hybrid-ink text-white text-center relative overflow-hidden">
          <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
          <div className="container relative z-10">
            <h2 className="font-serif font-bold text-4xl md:text-5xl mb-6">
              Ready to Upgrade Your Lifestyle?
            </h2>
            <p className="text-white/70 text-lg max-w-2xl mx-auto mb-10 font-light">
              Don't waste hours scrolling through outdated listings. Let our experts handle the search for you, completely free.
            </p>
            <button 
              onClick={() => window.open('https://form.typeform.com/to/S0I5M7ZZ?typeform-source=ko-real-estate.typeform.com', '_blank')}
              className="btn-luxury bg-gradient-to-r from-hybrid-gold to-[#8B6914] hover:from-[#d4af37] hover:to-[#8B6914]"
            >
              Get My Custom List
            </button>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-white border-t border-hybrid-sand/30 py-12">
        <div className="container text-center">
          <h3 className="font-serif font-bold text-2xl text-hybrid-ink mb-2">K.O. Real Estate Team</h3>
          <p className="font-ui text-xs text-hybrid-charcoal/50 uppercase tracking-widest mb-8">Spirit Real Estate Group, LLC</p>
          
          <div className="flex justify-center gap-8 mb-8">
            {["Privacy Policy", "Terms of Service", "Cookie Policy"].map((link) => (
              <a key={link} href="#" className="text-sm text-hybrid-charcoal/70 hover:text-hybrid-blue transition-colors">
                {link}
              </a>
            ))}
          </div>
          
          <p className="text-sm text-hybrid-charcoal/40">
            &copy; {new Date().getFullYear()} All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
